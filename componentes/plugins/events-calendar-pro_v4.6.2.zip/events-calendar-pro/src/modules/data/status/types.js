/* eslint-disable max-len */
/**
 * Internal dependencies
 */
import { PREFIX_EVENTS_PRO_STORE } from '@moderntribe/events-pro/data/prefix';

export const SET_SERIES_QUEUE_STATUS = `${ PREFIX_EVENTS_PRO_STORE }/SET_SERIES_QUEUE_STATUS`;
