<?php

class Tribe__Events__Pro__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = '';

}
