<?php
/**
 * @deprecated 4.3 use Tribe__Events__Pro__Shortcodes__Register
 */
class Tribe__Events__Pro__Shortcodes__Widget_Wrappers extends Tribe__Events__Pro__Shortcodes__Register {
	public function __construct() {
		_deprecated_function( __CLASS__, '4.3', 'Tribe__Events__Pro__Shortcodes__Register' );
	}
}