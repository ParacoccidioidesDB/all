<?php
namespace Ari_Adminer\Controllers\Settings;

use Ari\Controllers\Display as Display_Controller;

class Display extends Display_Controller {}