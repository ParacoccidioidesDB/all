<?php
define( 'ADMINER_WRAPPER_TYPE', 'adminer' );

require_once dirname( __FILE__ ) . '/wrapper.php';
